library(sf)
# Shapefile from ABS: 
# https://www.abs.gov.au/AUSSTATS/abs@.nsf/DetailsPage/1270.0.55.004July%202016?OpenDocument
map = read_sf("CTPRVN.shp")[1,]

pnts=data.frame(y=1950000,x=950000)

#pnts=data.frame(y=1940000,x=940000)

pnts_sf <- st_as_sf(pnts, coords = c('x', 'y'), crs = st_crs(map))

st_intersects(pnts_sf, map)




#setwd("C:/Users/wonchang.FRN5516-MKC2/Dropbox/SeoulMap")
#library(maptools)
#shape_object<- readShapePoly("CTPRVN.shp")
#proj4string(shape_object) <- CRS("+proj=tmerc +lat_0=38 +lon_0=127 +k=1 +x_0=200000 +y_0=500000 +ellps=bessel +units=m")

#plot(shape_object@polygons[[1]]@Polygons[[1]]@coords)

#seoul <- shape_object@polygons[[1]]@Polygons

#point<-data.frame(x=0,y=0)

#coordinates(point) <- ~x+y

#proj4string(point) <- proj4string(shape_object)

#over(point,seoul)
