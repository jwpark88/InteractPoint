#include <RcppArmadillo.h>
#include <limits>
#include <omp.h>
#define min(x,y) (((x) < (y)) ? (x) : (y))

using namespace std;
using namespace Rcpp;
using namespace arma;




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate likelihood part
double logpXCbeta(mat X, mat CC, double alpha, double omega, double AreaW, double integral){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
vec dummy; 

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){
	    d =  X.row(i) - CC.row(j);
		dummy =  (d*trans(d)); 
        res[i] = res[i] + exp(-dummy[0]/(2*omega*omega));
    }
}
double lik = AreaW - alpha*integral + nXrows*log(alpha/(2*(M_PI)*omega*omega)) + sum(log(res));

return(lik);
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate r1 and r2
vec coeff(vec theta){
	
vec r(2);
double t1 = theta[0], t2 = theta[1], t3 = 0.5, R = 0; 
double a = (t2-R)*(t2-R)/(t1*t3*t3); 
double b = t3*t3*(t1 - 1);
double d = 27*a*b*b;
double c = pow(d + sqrt((d+2)*(d+2)-4) + 2,1.0/3.0); 
double deltar = 1/(3*b) * ( c/pow(2,1.0/3.0) + pow(2,1.0/3.0)/c + 1 );
r[0] = a / pow(deltar,1.5)+ t2;
r[1] = r[0] - sqrt(deltar);

return(r);	
}


// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Birth step attraction-repulsion likelihood evaluation 
List BirthInteractionLik(vec xprop, mat CC, rowvec rho0sum, vec theta, vec r){

int count = CC.n_rows;    
double r1 = r[0], r2 = r[1], t1 = theta[0], t2 = theta[1], t3 = 0.5, R = 0;
double distance; 
rowvec logrb = zeros<rowvec>(count);
for(int i = 0; i< count; i++){
	distance = sqrt( (xprop[0] - CC(i,0))*(xprop[0] - CC(i,0)) + (xprop[1] - CC(i,1))*(xprop[1] - CC(i,1)) );
	if(distance>3000){
    logrb[i] = log(1);
    }else if ( (distance>r1) && (distance<=3000) ){
    logrb[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
    }else if ( (distance>R) && (distance<=r1) ){
    logrb[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
	}	  	
	}
		
	rowvec rhosum = rho0sum + logrb;
    rhosum.insert_cols(count,1);
    rhosum[count] = sum(trans(logrb));
    
    double likelihood = 0; 
	for(int i = 0; i<count+1; i++){
    	likelihood = min(rhosum[i],2) + likelihood;
    }


return List::create(Named("likelihood") = likelihood, Named("rhosum") = rhosum);
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// Death step attraction-repulsion likelihood evaluation 
List DeathInteractionLik(vec xprop, int Death, mat CC, rowvec rho0sum, vec theta, vec r){

Death = Death - 1; // for C code matching index
int count = CC.n_rows;    
double r1 = r[0], r2 = r[1], t1 = theta[0], t2 = theta[1], t3 = 0.5, R = 0;
double distance; 
rowvec logrd = zeros<rowvec>(count);
for(int i = 0; i< count; i++){
	distance = sqrt( (xprop[0] - CC(i,0))*(xprop[0] - CC(i,0)) + (xprop[1] - CC(i,1))*(xprop[1] - CC(i,1)) );
    if(distance>3000){
    logrd[i] = log(1);
    }else if ( (distance>r1) && (distance<=3000) ){
    logrd[i] = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
    }else if ( (distance>R) && (distance<=r1) ){
    logrd[i] = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
    }
	}
	
	rowvec rhosum = rho0sum - logrd;
	rhosum.shed_col(Death);
	
	double likelihood = 0; 
	for(int i = 0; i<count-1; i++){
    	likelihood = min(rhosum[i],2) + likelihood;
    }

return List::create(Named("likelihood") = likelihood, Named("rhosum") = rhosum);
}



// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// evaluate unnormalized likelihood for auxiliary variable  
double pCClik(vec thetaprop, mat CC){
	
    int count = CC.n_rows; 
	vec r = coeff(thetaprop);
    double r1 = r[0], r2 = r[1], t1 = thetaprop[0], t2 = thetaprop[1], t3 = 0.5, R = 0;


    // lhY and lhYp
    double distance;
    mat resultCCp = zeros(count,count);
    for(int i = 0; i < count; i++){
    for(int j = 0; j <= i; j++){
    distance = sqrt( (CC(i,0) - CC(j,0))*(CC(i,0) - CC(j,0)) + (CC(i,1) - CC(j,1))*(CC(i,1) - CC(j,1)) );	
    
        if(distance>3000){
        resultCCp(i,j) = resultCCp(j,i) = log(1);
        }else if ( (distance>r1) && (distance<=3000) ){
        resultCCp(i,j) = resultCCp(j,i) = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        resultCCp(i,j) = resultCCp(j,i) = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }else {
        resultCCp(i,j) = resultCCp(j,i) = 0;
        }
        
        }
    }  
    
    rowvec rhoCCpsum = sum(resultCCp);  
    double lhCCp = 0; 
    for(int i = 0; i<count; i++){
    	lhCCp = min(rhoCCpsum[i],2) + lhCCp;
        }
 


return(lhCCp);
}




// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// evaluate unnormalized likelihood for auxiliary variable  
List pCClik2(vec thetaprop, mat CC){
	
    int count = CC.n_rows; 
	vec r = coeff(thetaprop);
    double r1 = r[0], r2 = r[1], t1 = thetaprop[0], t2 = thetaprop[1], t3 = 0.5, R = 0;


    // lhY and lhYp
    double distance;
    mat resultCCp = zeros(count,count);
    for(int i = 0; i < count; i++){
    for(int j = 0; j <= i; j++){
    distance = sqrt( (CC(i,0) - CC(j,0))*(CC(i,0) - CC(j,0)) + (CC(i,1) - CC(j,1))*(CC(i,1) - CC(j,1)) );	
    
        if(distance>3000){
        resultCCp(i,j) = resultCCp(j,i) = log(1);
        }else if ( (distance>r1) && (distance<=3000) ){
        resultCCp(i,j) = resultCCp(j,i) = log( 1 + 1/(t3*t3*(distance-r2)*(distance-r2)) );
        }else if ( (distance>R) && (distance<=r1) ){
        resultCCp(i,j) = resultCCp(j,i) = log( t1 - (sqrt(t1)*(distance-t2)/(t2-R))*(sqrt(t1)*(distance-t2)/(t2-R)) );
        }else {
        resultCCp(i,j) = resultCCp(j,i) = 0;
        }
        
        }
    }  
    
    rowvec rhoCCpsum = sum(resultCCp);  
    double lhCCp = 0; 
    for(int i = 0; i<count; i++){
    	lhCCp = min(rhoCCpsum[i],2) + lhCCp;
        }
 
return List::create(Named("likelihood") = lhCCp, Named("rhosum") = rhoCCpsum);
}











// [[Rcpp::depends("RcppArmadillo")]]
// [[Rcpp::export]]
// calculate temproal likelihood part
double logpCCtemp(mat X, mat CC, double alpha, double omega, double numratio, double AreaW, double integral){
	
int nXrows = X.n_rows;    
int nCCrows = CC.n_rows;    
rowvec d;
vec res = zeros(nXrows);
vec dummy; 

for(int i = 0; i< nXrows; i++){
    for(int j = 0; j< nCCrows; j++){
	    d =  X.row(i) - CC.row(j);
		dummy =  (d*trans(d)); 
        res[i] = res[i] + numratio*exp(-dummy[0]/(2*omega*omega));
    }
}
double lik = AreaW - alpha*integral + nXrows*log(alpha/(2*(M_PI)*omega*omega)) + sum(log(res));

return(lik);
}





































